/**
 * Hello World! Problem Sets - Graphical Java
 * Your Discord Username and Tag:
 * Date of Completion:
 */

public class SetOne {

    public SetOne() {

    }

    public static void main (String[] args) {
        long startTime = System.nanoTime();
        SetOne s = new SetOne();
        long endTime = System.nanoTime();

        long duration = (endTime - startTime);
        System.out.println("Completed in: " + duration + " nanoseconds.");

        /**
         * NOTE: Tampering with the timing function will invalidate your submission!
         */
    }
}
